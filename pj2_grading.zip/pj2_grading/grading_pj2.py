import os
import sys
import subprocess
import os.path


#AFD
afd1="hex.afd,afd/hex.afd,afd/tests/hex.txt"
afd2="variables.afd,afd/variables.afd,afd/tests/variables.txt"
afd3="weird_expression.afd,afd/weird_expression.afd,afd/tests/weird_expression.txt"
afd4="pseudo_float.afd,afd/pseudo_float.afd,afd/tests/pseudo_float.txt"
afd5="simple.afd,afd/simple.afd,afd/tests/simple.txt"
# Soluciones
#afd1
s1 = "0x,RECHAZADA"
s2 = "0x1,ACEPTADA"
s3 = "x12,RECHAZADA"
s4 = "0x1D40,ACEPTADA"
s5 = "0xF0FF2001,ACEPTADA"
#afd2
s6 = "variable1,ACEPTADA"
s7 = "_variable2,ACEPTADA"
s8 = "4estano,RECHAZADA"
s9 = "contador_1,ACEPTADA"
s10 = "1_contador,RECHAZADA"
#afd3
s11 = "aaabc2,ACEPTADA" 
s12 = "bc23ab,RECHAZADA"
s13 = "aaaaabc33,ACEPTADA"
s14 = "bcbc33a,RECHAZADA"
s15 = "aaabcba2a3,RECHAZADA"
#afd4
s16 = "12.345e2,ACEPTADA"
s17 ="7.258,ACEPTADA"
s18 ="e324,RECHAZADA"
s19 ="234.,RECHAZADA"
s20 ="912.123e0,ACEPTADA"
#afd5
s21 = "1,ACEPTADA"
s22 ="0,RECHAZADA"
s23 ="11,ACEPTADA"
s24 ="10,RECHAZADA"
s25 ="011,RECHAZADA"

s26 ="ACEPTADA"
s27 ="RECHAZADA"
s28 ="ACEPTADA"
s29 ="RECHAZADA"
s30 ="ACEPTADA"

s31 ="ACEPTADA"
s32 ="ACEPTADA"
s33 ="RECHAZADA"
s34 ="RECHAZADA"
s35 ="RECHAZADA"

s36 ="RECHAZADA"
s37 ="ACEPTADA"
s38 ="RECHAZADA"
s39 ="RECHAZADA"
s40 ="ACEPTADA"

s41 ="RECHAZADA"
s42 ="ACEPTADA"
s43 ="ACEPTADA"
s44 ="RECHAZADA"
s45 ="ACEPTADA"

s46 ="ACEPTADA"
s47 ="RECHAZADA"
s48 ="RECHAZADA"
s49 ="RECHAZADA"
s50 ="ACEPTADA"


def checkScoreI(total,tests,separator=","):
	score_per_afd = float(total)/len(tests)
	for i,test in enumerate(tests):
		afd_name,afd,text_file = test[0].split(separator)
		print ">>PROBANDO java AfdMachine "+afd+" -i "
		process = subprocess.Popen("java AfdMachine "+afd+" -i ", shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
		strings = test[1]
		score_per_test = score_per_afd/len(strings)
		for j,string in enumerate(strings):
			cmd,result = string.split(separator)
			process.stdin.write(cmd + "\n")
			output =  process.stdout.readline().strip()
			feedback = "CUERDA: "+cmd.rjust(10)+" ESPERADO: "+result.rjust(9)+ ", RECIBIDO: "+output.rjust(9)
			if result != output:
				total-=score_per_test
				feedback+=" (+0)"
			else:
				feedback+= " (+"+str(round(score_per_test,2))+")"
			print feedback
		print "."*20
		process.stdin.write("\n")
	return total

def checkScoreB(total,tests,separator=","):
	score_per_afd = float(total)/len(tests)
	for i,test in enumerate(tests):
		afd_name,afd,text_file = test[0].split(separator)
		print ">>PROBANDO java AfdMachine "+afd+" -b " +text_file
		process = subprocess.Popen("java AfdMachine "+afd+" -b "+text_file, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
		strings = test[1]
		score_per_test = score_per_afd/len(strings)
		output =  process.stdout.readlines()
		for j,expected_output in enumerate(strings):
			current_output = output[j].strip()
			feedback = " ESPERADO: "+expected_output.rjust(9)+ ", RECIBIDO: "+current_output.rjust(9)
			if expected_output != current_output:
				total-=score_per_test
				feedback+=" (+0)"
			else:
				feedback+= " (+"+str(round(score_per_test,2))+")"
			print feedback
		print "."*20
	return total


def main():
	tests = [(afd1,[s1,s2,s3,s4,s5]),(afd2,[s6,s7,s8,s9,s10]),(afd3,[s11,s12,s13,s14,s15]),(afd4,[s16,s17,s18,s19,s20]),(afd5,[s21,s22,s23,s24,s25])]
	print "..MODO INTERACTIVE.."
	scoreI = checkScoreI(50,tests)
	print ".....MODO BATCH....."
	tests = [(afd1,[s26,s27,s28,s29,s30]),(afd2,[s31,s32,s33,s34,s35]),(afd3,[s36,s37,s38,s39,s40]),(afd4,[s41,s42,s43,s44,s45]),(afd5,[s46,s47,s48,s49,s50])]
	scoreB = checkScoreB(50,tests)
	print "."*20
	print "Nota Total: "+str(round(scoreB+scoreI,2))+"/100"


if __name__ == '__main__':
    main()


